//#region node_modules/.nitro/vite/services/ssr/assets/master-poker-hero.jpg.asset-CByH3_u4.js
var master_poker_hero_jpg_asset_default = {
	version: 1,
	asset_id: "585392a7-e48d-4232-9c5b-2f9b8e61645a",
	project_id: "de3d16fa-9fe6-498e-ac1a-6cfb192db38d",
	url: "/__l5e/assets-v1/585392a7-e48d-4232-9c5b-2f9b8e61645a/master-poker-hero.jpg",
	r2_key: "a/v1/de3d16fa-9fe6-498e-ac1a-6cfb192db38d/585392a7-e48d-4232-9c5b-2f9b8e61645a/master-poker-hero.jpg",
	original_filename: "master-poker-hero.jpg",
	size: 917652,
	content_type: "image/jpeg",
	created_at: "2026-11-11T00:51:13Z"
};
//#endregion
export { master_poker_hero_jpg_asset_default as t };
